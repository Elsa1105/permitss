import { NextResponse } from "next/server";
import { createServerSupabase } from "@/lib/supabase/server";
import { buildPermitPdfBytes } from "@/lib/pdf/build-permit-pdf";

export async function GET(
  _request: Request,
  ctx: { params: Promise<{ id: string }> },
) {
  const { id } = await ctx.params;
  const supabase = await createServerSupabase();

  const { data: auth } = await supabase.auth.getUser();

  if (!auth.user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const result = await buildPermitPdfBytes(supabase, id);

  if (!result) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  return new NextResponse(new Uint8Array(result.bytes).buffer as ArrayBuffer, {
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": `inline; filename="${result.serialNo}.pdf"`,
      "Cache-Control": "no-store",
    },
  });
}
