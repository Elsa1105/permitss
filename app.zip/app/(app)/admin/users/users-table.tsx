"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog } from "@/components/ui/dialog";
import { Input, Select } from "@/components/ui/input";
import type { UserRow } from "@/lib/supabase/types";

const ROLE_OPTIONS = [
  { value: "applicant", label: "Applicant" },
  { value: "guest_applicant", label: "Guest Applicant" },
  { value: "contractor", label: "Contractor" },
  { value: "assessor", label: "Safety Assessor" },
  { value: "srm", label: "SRM" },
  { value: "admin", label: "Admin" },
];

const QUALIFICATION_OPTIONS = [
  "hot_work_applicant",
  "hot_work_assessor",
  "hot_work_srm",
  "lifting_applicant",
  "lifting_assessor",
  "lifting_srm",
  "bunkering_applicant",
  "bunkering_assessor",
  "bunkering_srm",
];

export function UsersTable({
  users,
  currentUserId,
}: {
  users: UserRow[];
  currentUserId: string;
}) {
  const router = useRouter();

  const [linkedDeleteUser, setLinkedDeleteUser] = React.useState<UserRow | null>(null);
  const [busyId, setBusyId] = React.useState<string | null>(null);
  const [editingId, setEditingId] = React.useState<string | null>(null);

  const [resetTarget, setResetTarget] = React.useState<UserRow | null>(null);
  const [resetPassword, setResetPassword] = React.useState("");
  const [resetConfirm, setResetConfirm] = React.useState("");
  const [resetBusy, setResetBusy] = React.useState(false);

  function openResetDialog(user: UserRow) {
    setResetTarget(user);
    setResetPassword("");
    setResetConfirm("");
  }

  function closeResetDialog() {
    setResetTarget(null);
    setResetPassword("");
    setResetConfirm("");
  }

  async function submitReset() {
    if (!resetTarget) return;

    if (resetPassword.length < 8) {
      toast.error("Password must be at least 8 characters");
      return;
    }

    if (resetPassword !== resetConfirm) {
      toast.error("Passwords do not match");
      return;
    }

    setResetBusy(true);

    try {
      const res = await fetch(
        `/api/admin/users/${resetTarget.id}/reset-password`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ password: resetPassword }),
        },
      );

      const body = await res.json();

      if (!res.ok) {
        toast.error(body.error || "Reset failed");
        return;
      }

      toast.success(
        body.recreated
          ? `Login recreated for ${resetTarget.full_name} — their account had no working sign-in; they can log in with this new password now.`
          : `Password updated for ${resetTarget.full_name}`,
      );
      closeResetDialog();
    } finally {
      setResetBusy(false);
    }
  }

  const [editForm, setEditForm] = React.useState<{
    full_name: string;
    department: string;
    role: UserRow["role"];
    qualified_for: string[];
    active: boolean;
  } | null>(null);

  function startEdit(user: UserRow) {
    setEditingId(user.id);
    setEditForm({
      full_name: user.full_name,
      department: user.department ?? "",
      role: user.role,
      qualified_for: user.qualified_for ?? [],
      active: user.active,
    });
  }

  function cancelEdit() {
    setEditingId(null);
    setEditForm(null);
  }

  function toggleQualification(value: string) {
    setEditForm((current) => {
      if (!current) return current;

      return {
        ...current,
        qualified_for: current.qualified_for.includes(value)
          ? current.qualified_for.filter((item) => item !== value)
          : [...current.qualified_for, value],
      };
    });
  }

  async function saveEdit(user: UserRow) {
    if (!editForm) return;

    if (!editForm.full_name.trim()) {
      toast.error("Full name is required");
      return;
    }

    if (user.id === currentUserId && editForm.active === false) {
      toast.error("You cannot deactivate your own admin account");
      return;
    }

    if (user.id === currentUserId && editForm.role !== "admin") {
      toast.error("You cannot remove your own admin role");
      return;
    }

    setBusyId(user.id);

    try {
      const res = await fetch(`/api/admin/users/${user.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          full_name: editForm.full_name.trim(),
          department: editForm.department.trim() || null,
          role: editForm.role,
          qualified_for: editForm.qualified_for,
          active: editForm.active,
        }),
      });

      const body = await res.json();

      if (!res.ok) {
        toast.error(body.error || "Update failed");
        return;
      }

      toast.success("User updated");
      cancelEdit();
      router.refresh();
    } finally {
      setBusyId(null);
    }
  }

  async function deleteUser(user: UserRow) {
    if (user.id === currentUserId) {
      toast.error("You cannot delete your own account");
      return;
    }

    const confirmation = window.prompt(`Remove access for ${user.full_name} (${user.email})?\nThis hides the account from Users and blocks sign-in. Permit and audit history stay intact.\nType REMOVE ACCOUNT to continue:`);
    if (confirmation !== "REMOVE ACCOUNT") return;
    const reason = window.prompt("Reason for removing this account (at least 10 characters):");
    if (!reason || reason.trim().length < 10) { toast.error("Reason must be at least 10 characters"); return; }

    setBusyId(user.id);

    try {
      const res = await fetch(`/api/admin/users/${user.id}`, {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ confirmation, reason }),
      });

      const body = await res.json().catch(() => ({}));

      if (!res.ok) {
        if (res.status === 409 && body.can_deactivate === true) {
          setLinkedDeleteUser(user);
        } else {
          toast.error(body.error || "Delete failed");
        }
        return;
      }

      toast.success(`${user.full_name} removed from Users and sign-in disabled; historical records retained`);
      router.refresh();
    } finally {
      setBusyId(null);
    }
  }

  async function toggleActive(user: UserRow) {
    if (user.id === currentUserId && user.active) {
      toast.error("You cannot deactivate your own admin account");
      return;
    }

    setBusyId(user.id);

    try {
      const res = await fetch(`/api/admin/users/${user.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ active: !user.active }),
      });

      const body = await res.json();

      if (!res.ok) {
        toast.error(body.error || "Update failed");
        return;
      }

      toast.success(
        `${user.full_name} ${!user.active ? "activated" : "deactivated"}`,
      );

      router.refresh();
      setLinkedDeleteUser(null);
    } finally {
      setBusyId(null);
    }
  }

  if (!users.length) {
    return (
      <div className="p-6 text-sm text-slate-500 text-center">No users yet.</div>
    );
  }

  return (
    <div className="overflow-x-auto">
      {/* Fixed layout + colgroup below pin every column to a set share of
          the container's width, so the table always fits the screen
          instead of growing wider than it (that auto-growth — driven
          mostly by the long qualified_for text — is what pushed "Reset
          Password" off-screen and forced constant side-scrolling). Long
          text now wraps onto extra lines within its column instead. */}
      <table className="table-base table-fixed">
        <colgroup>
          <col className="w-[15%]" />
          <col className="w-[20%]" />
          <col className="w-[11%]" />
          <col className="w-[10%]" />
          <col className="w-[20%]" />
          <col className="w-[12%]" />
          <col className="w-[12%]" />
        </colgroup>
        <thead>
          <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Department</th>
            <th>Role</th>
            <th>Qualified for</th>
            <th>Status</th>
            <th aria-label="Actions" />
          </tr>
        </thead>

        <tbody>
          {users.map((user) => {
            const isEditing = editingId === user.id && editForm;
            const isSelf = user.id === currentUserId;

            if (isEditing) {
              return (
                <tr key={user.id}>
                  <td className="align-top">
                    <Input
                      label="Name"
                      value={editForm.full_name}
                      onChange={(e) =>
                        setEditForm((current) =>
                          current
                            ? { ...current, full_name: e.target.value }
                            : current,
                        )
                      }
                    />
                  </td>

                  <td className="text-slate-600 align-top break-words">{user.email}</td>

                  <td className="align-top">
                    <Input
                      label="Department"
                      value={editForm.department}
                      onChange={(e) =>
                        setEditForm((current) =>
                          current
                            ? { ...current, department: e.target.value }
                            : current,
                        )
                      }
                    />
                  </td>

                  <td className="align-top">
                    <Select
                      label="Role"
                      value={editForm.role}
                      onChange={(e) =>
                        setEditForm((current) =>
                          current
                            ? {
                                ...current,
                                role: e.target.value as UserRow["role"],
                              }
                            : current,
                        )
                      }
                      options={ROLE_OPTIONS}
                      disabled={isSelf}
                    />
                  </td>

                  <td className="align-top">
                    <div className="space-y-1">
                      {QUALIFICATION_OPTIONS.map((q) => (
                        <label
                          key={q}
                          className="flex items-center gap-2 text-xs text-slate-700"
                        >
                          <input
                            type="checkbox"
                            checked={editForm.qualified_for.includes(q)}
                            onChange={() => toggleQualification(q)}
                          />
                          <span className="break-words">{q}</span>
                        </label>
                      ))}
                    </div>
                  </td>

                  <td className="align-top">
                    <select
                      className="input"
                      value={editForm.active ? "active" : "inactive"}
                      onChange={(e) =>
                        setEditForm((current) =>
                          current
                            ? {
                                ...current,
                                active: e.target.value === "active",
                              }
                            : current,
                        )
                      }
                      disabled={isSelf}
                    >
                      <option value="active">Active</option>
                      <option value="inactive">Inactive</option>
                    </select>
                  </td>

                  <td className="text-right align-top">
                    <div className="flex flex-col items-end gap-2">
                      <Button
                        type="button"
                        loading={busyId === user.id}
                        onClick={() => saveEdit(user)}
                      >
                        Save
                      </Button>

                      <Button
                        type="button"
                        variant="secondary"
                        onClick={cancelEdit}
                      >
                        Cancel
                      </Button>
                    </div>
                  </td>
                </tr>
              );
            }

            return (
              <tr key={user.id}>
                <td className="font-medium align-top break-words">
                  {user.full_name}
                  {isSelf ? (
                    <span className="ml-2 text-xs text-slate-400">(you)</span>
                  ) : null}
                </td>

                <td className="text-slate-600 align-top break-words">{user.email}</td>

                <td className="text-slate-600 align-top break-words">
                  {user.department ?? "—"}
                </td>

                <td className="align-top">
                  <Badge tone="info" className="capitalize">
                    {user.role}
                  </Badge>
                </td>

                <td className="text-xs text-slate-600 align-top break-words">
                  {(user.qualified_for ?? []).length
                    ? user.qualified_for.join(", ")
                    : "—"}
                </td>

                <td className="align-top">
                  <Badge tone={user.active ? "ok" : "neutral"}>
                    {user.active ? "Active" : "Inactive"}
                  </Badge>
                  {user.must_change_password ? (
                    <div className="mt-1">
                      <Badge tone="warn" className="text-[10px]">
                        Must change password
                      </Badge>
                    </div>
                  ) : null}
                </td>

                <td className="text-right align-top">
                  {/* Every action stacked on its own line (rather than
                      "Edit" + "Deactivate" side by side) so this column
                      never needs more width than the narrow share it's
                      given, and nothing gets pushed off the right edge. */}
                  <div className="flex flex-col items-end gap-1 text-sm">
                    <button
                      type="button"
                      className="text-blue-600 hover:underline disabled:opacity-50"
                      disabled={busyId === user.id}
                      onClick={() => startEdit(user)}
                    >
                      Edit
                    </button>

                    <button
                      type="button"
                      className="text-blue-600 hover:underline disabled:opacity-50 disabled:cursor-not-allowed"
                      disabled={busyId === user.id || (isSelf && user.active)}
                      onClick={() => toggleActive(user)}
                      title={
                        isSelf && user.active
                          ? "You cannot deactivate your own account"
                          : undefined
                      }
                    >
                      {user.active ? "Deactivate" : "Activate"}
                    </button>

                    <button
                      type="button"
                      className="text-blue-600 hover:underline disabled:opacity-50"
                      disabled={busyId === user.id}
                      onClick={() => openResetDialog(user)}
                    >
                      Reset
                    </button>

                    <button
                      type="button"
                      className="text-red-600 hover:underline disabled:opacity-50 disabled:cursor-not-allowed"
                      disabled={busyId === user.id || isSelf}
                      onClick={() => deleteUser(user)}
                      title={
                        isSelf ? "You cannot delete your own account" : undefined
                      }
                    >
                      Delete
                    </button>
                  </div>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>

      <Dialog open={!!linkedDeleteUser} onClose={() => setLinkedDeleteUser(null)} title="Account cannot be deleted">
        <div className="space-y-4 p-4">
          <p className="text-sm text-slate-700">This account has linked historical records or has not been independently verified as a test account. This account has linked records or requires independent verification. Unused accounts can be deleted directly using the Delete button. Historical records are protected; you can deactivate instead.</p>
          <div className="flex justify-end gap-3">
            <Button variant="secondary" onClick={() => setLinkedDeleteUser(null)}>Cancel</Button>
            <Button disabled={!linkedDeleteUser?.active || busyId === linkedDeleteUser?.id} onClick={() => { if(linkedDeleteUser) void toggleActive(linkedDeleteUser); }}>
              Deactivate account
            </Button>
          </div>
        </div>
      </Dialog>

      <Dialog
        open={!!resetTarget}
        onClose={closeResetDialog}
        title="Reset Password"
        description={
          resetTarget
            ? `Set a new password for ${resetTarget.full_name} (${resetTarget.email}). If their login was somehow removed, this recreates it automatically.`
            : undefined
        }
        size="sm"
        footer={
          <>
            <Button type="button" variant="secondary" onClick={closeResetDialog}>
              Cancel
            </Button>
            <Button type="button" loading={resetBusy} onClick={submitReset}>
              Update Password
            </Button>
          </>
        }
      >
        <div className="space-y-4">
          <Input
            label="New Password"
            type="password"
            required
            hint="Minimum 8 characters."
            value={resetPassword}
            onChange={(e) => setResetPassword(e.target.value)}
            autoComplete="new-password"
          />
          <Input
            label="Confirm New Password"
            type="password"
            required
            value={resetConfirm}
            onChange={(e) => setResetConfirm(e.target.value)}
            autoComplete="new-password"
          />
        </div>
      </Dialog>
    </div>
  );
}