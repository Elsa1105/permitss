import { NextResponse } from "next/server";
import { createServerSupabase } from "@/lib/supabase/server";
import { Stage3Schema } from "@/lib/permits/schemas";
import { notifyPermitEvent } from "@/lib/notifications/permit-emails";
import { checkLiftingAccess } from "@/lib/permits/lifting-access";
import { checkBunkeringAccess } from "@/lib/permits/bunkering-access";

export async function POST(
  request: Request,
  ctx: { params: Promise<{ id: string }> },
) {
  const { id } = await ctx.params;
  const supabase = await createServerSupabase();

  const { data: auth } = await supabase.auth.getUser();

  if (!auth.user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  // Lifting permits: only the approved Lifting SRM / PM pool (no-op for others).
  const liftingDenied = await checkLiftingAccess(supabase, id, auth.user.id, [
    "lifting_srm",
  ]);

  if (liftingDenied) {
    return NextResponse.json({ error: liftingDenied }, { status: 403 });
  }

  // Bunkering permits: only the approved Bunkering pool (no-op for others).
  const bunkeringDenied = await checkBunkeringAccess(supabase, id, auth.user.id, [
    "bunkering_srm",
  ]);

  if (bunkeringDenied) {
    return NextResponse.json({ error: bunkeringDenied }, { status: 403 });
  }

  const body = await request.json().catch(() => null);
  const parsed = Stage3Schema.safeParse(body);

  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.issues[0]?.message ?? "Validation failed" },
      { status: 400 },
    );
  }

  const cleanedReason = parsed.data.reason?.trim() ?? "";

  const { data, error } = await supabase.rpc("permit_submit_stage3", {
    p_permit_id: id,
    p_decision: parsed.data.decision,
    p_reason: cleanedReason,
  });

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 400 });
  }

  await notifyPermitEvent({
    supabase,
    permitId: id,
    event:
      parsed.data.decision === "approve"
        ? "stage3_approved"
        : "stage3_rejected",
    note: cleanedReason,
  });

  return NextResponse.json(data);
}