import { NextResponse } from "next/server";
import { createServerSupabase, createServiceRoleSupabase } from "@/lib/supabase/server";
import { canCreatePermitType } from "@/lib/permits/type-permissions";
import { NewPermitSchema } from "@/lib/permits/schemas";
import { notifyPermitEvent } from "@/lib/notifications/permit-emails";
import {
  hasLiftingQualification,
  isLiftingPermit,
} from "@/lib/permits/lifting";
import {
  hasBunkeringQualification,
  isBunkeringPermit,
} from "@/lib/permits/bunkering";

const ALLOWED_CREATOR_ROLES = new Set([
  "applicant",
  "guest_applicant",
  "contractor",
  "admin",
  "srm",
]);

export async function POST(request: Request) {
  const supabase = await createServerSupabase();
  const serviceSupabase = createServiceRoleSupabase();

  const { data: auth } = await supabase.auth.getUser();

  if (!auth.user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  let body: unknown;

  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON" }, { status: 400 });
  }

  const parsed = NewPermitSchema.safeParse(body);

  if (!parsed.success) {
    return NextResponse.json(
      {
        error: "Validation failed",
        issues: parsed.error.issues,
      },
      { status: 400 },
    );
  }

  const payload = parsed.data;

  const { data: currentUser, error: userError } = await supabase
    .from("users")
    .select("id, role, active, qualified_for")
    .eq("id", auth.user.id)
    .single();

  if (userError || !currentUser) {
    return NextResponse.json(
      { error: "User profile not found" },
      { status: 403 },
    );
  }

  if (!currentUser.active) {
    return NextResponse.json(
      { error: "User account is inactive" },
      { status: 403 },
    );
  }

  if (!canCreatePermitType(currentUser, payload.permit_type)) {
    return NextResponse.json(
      { error: "You are not allowed to create a permit" },
      { status: 403 },
    );
  }

  // Lifting permits are raised only by the approved Lifting Supervisors.
  if (
    isLiftingPermit(payload.permit_type) &&
    !hasLiftingQualification(currentUser, "lifting_applicant")
  ) {
    return NextResponse.json(
      {
        error:
          "Only approved Lifting Supervisors can raise a Lifting Permit",
      },
      { status: 403 },
    );
  }

  // Hazardous Work (bunkering_operation) permits are raised only by approved applicants.
  if (
    isBunkeringPermit(payload.permit_type) &&
    !hasBunkeringQualification(currentUser, "bunkering_applicant")
  ) {
    return NextResponse.json(
      {
        error:
          "Only approved Foremen / Supervisors can raise a Hazardous Work Permit",
      },
      { status: 403 },
    );
  }

  const isGuestApplicant =
    currentUser.role === "guest_applicant" ||
    currentUser.role === "contractor";

  if (isGuestApplicant) {
    if (!payload.contractor_company?.trim()) {
      return NextResponse.json(
        { error: "Contractor company is required for guest applicant" },
        { status: 400 },
      );
    }

    if (!payload.contractor_supervisor_name?.trim()) {
      return NextResponse.json(
        { error: "Contractor supervisor name is required for guest applicant" },
        { status: 400 },
      );
    }

    if (!payload.contractor_supervisor_registration_no?.trim()) {
      return NextResponse.json(
        {
          error:
            "Contractor supervisor registration number is required for guest applicant",
        },
        { status: 400 },
      );
    }

    if (!payload.worker_briefing_acknowledged) {
      return NextResponse.json(
        {
          error:
            "Worker briefing acknowledgement is required for guest applicant",
        },
        { status: 400 },
      );
    }

    if (!payload.top_controls_summary?.trim()) {
      return NextResponse.json(
        {
          error: "Top controls summary is required for guest applicant",
        },
        { status: 400 },
      );
    }
  }

  const { data: company, error: companyError } = await serviceSupabase
    .from("companies")
    .select("code")
    .eq("id", payload.company_id)
    .single();

  if (companyError || !company) {
    return NextResponse.json(
      { error: "Selected company could not be found" },
      { status: 400 },
    );
  }

  const companyCode = company.code?.trim().toUpperCase() || "GEN";

const { data: serialData, error: serialErr } = await serviceSupabase.rpc(
  "next_permit_serial",
  { p_permit_type: `${payload.permit_type}_${companyCode.toLowerCase()}` },
);

  if (serialErr || !serialData) {
    return NextResponse.json(
      { error: serialErr?.message ?? "Could not generate serial number" },
      { status: 500 },
    );
  }

  const insert = await serviceSupabase
    .from("permits")
    .insert({
      serial_no: serialData as string,
      permit_type: payload.permit_type,
      company_id: payload.company_id,
      site_id: payload.site_id,
      state: "draft",

      display_applicant_name: payload.display_applicant_name || null,
      display_applicant_department:
        payload.display_applicant_department || null,
      job_type: payload.job_type,

      vessel_project: payload.vessel_project,
      location_of_work: payload.location_of_work,
      date_commencement: payload.date_commencement,
      date_completion: payload.date_completion,
      description: payload.description,

      hazard_types: payload.hazard_types,
      other_hazard_text: payload.other_hazard_text || null,

      contractor: payload.contractor || "",

      contractor_company: payload.contractor_company || null,
      contractor_supervisor_name:
        payload.contractor_supervisor_name || null,
      contractor_supervisor_registration_no:
        payload.contractor_supervisor_registration_no || null,
      worker_briefing_acknowledged:
        payload.worker_briefing_acknowledged ?? false,
      top_controls_summary: payload.top_controls_summary || null,

      applicant_id: auth.user.id,
    })
    .select("id, serial_no")
    .single();

  if (insert.error || !insert.data) {
    return NextResponse.json(
      { error: insert.error?.message ?? "Failed to create permit" },
      { status: 500 },
    );
  }

  // Log creation once, with the authenticated actor explicitly supplied.
  // Service-role RPCs cannot infer the acting user from auth.uid().
  const { error: auditError } = await serviceSupabase.from("audit_log").insert({
    permit_id: insert.data.id,
    actor_id: auth.user.id,
    action: isGuestApplicant ? "created_by_guest_applicant" : "created",
    from_state: null,
    to_state: "draft",
    reason: null,
  });
  if (auditError) {
    console.error("Failed to record permit creation audit", auditError);
    // Creation has committed; do not retry insert blindly (it would duplicate a permit).
    return NextResponse.json({
      error: "Permit was created, but its audit entry failed. Contact an administrator; do not resubmit.",
      permit_id: insert.data.id,
    }, { status: 500 });
  }

  await notifyPermitEvent({
    supabase: serviceSupabase,
    permitId: insert.data.id,
    event: "stage1_submitted",
  });

  return NextResponse.json(insert.data, { status: 201 });
}