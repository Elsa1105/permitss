"use client";

import * as React from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import {
  ClipboardList,
  FilePlus,
  LayoutDashboard,
  LogOut,
  Menu,
  Shield,
  Users,
  X,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { createBrowserSupabase } from "@/lib/supabase/client";
import { canCreatePermitType } from "@/lib/permits/type-permissions";
import type { UserRow } from "@/lib/supabase/types";

interface NavItem {
  href: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  roles?: UserRow["role"][];
}

const NAV: NavItem[] = [
  { href: "/dashboard",     label: "Dashboard", icon: LayoutDashboard },
  { href: "/permits",       label: "All Permits",   icon: ClipboardList },
  {
  href: "/permits/new",
  label: "New Hot Work Permit",
  icon: FilePlus,
  roles: ["applicant", "guest_applicant", "contractor", "srm", "admin"],
  },
  {
  href: "/permits/new/lifting",
  label: "New Lifting Permit",
  icon: FilePlus,
  roles: ["applicant", "guest_applicant", "contractor", "srm", "admin"],
  },
  {
  href: "/permits/new/bunkering",
  label: "New Hazardous Work Permit",
  icon: FilePlus,
  roles: ["applicant", "guest_applicant", "contractor", "srm", "admin"],
  },
  { href: "/admin/users",   label: "Users",     icon: Users,        roles: ["admin"] },
  { href: "/admin/audit",   label: "Audit Log", icon: Shield,       roles: ["admin"] },
];

export function AppShell({
  user,
  children,
  formNo = "FOI-SG-057",
}: {
  user: UserRow;
  children: React.ReactNode;
  formNo?: string;
}) {
  const router = useRouter();
  const pathname = usePathname();
  const [mobileOpen, setMobileOpen] = React.useState(false);


  const visibleNav = NAV.filter((n) => {
    if (n.href === "/permits/new") return canCreatePermitType(user, "hot_work_onshore");
    if (n.href === "/permits/new/lifting") return canCreatePermitType(user, "lifting_operation");
    if (n.href === "/permits/new/bunkering") return canCreatePermitType(user, "bunkering_operation");
    return !n.roles || n.roles.includes(user.role) || user.role === "admin";
  });

  async function signOut() {
    const supabase = createBrowserSupabase();
    await supabase.auth.signOut();
    router.replace("/login");
    router.refresh();
  }

  return (
    <div className="flex min-h-screen">
      {/* Sidebar (desktop) — narrowed from w-64/w-72 so the rightmost
          action column (e.g. Reset Password) on wide tables isn't cut off. */}
      <aside className="hidden md:flex md:w-52 lg:w-60 flex-col bg-white border-r border-slate-200 sticky top-0 h-screen">
        <SidebarContent
          user={user}
          pathname={pathname}
          nav={visibleNav}
          onSignOut={signOut}
          formNo={formNo}
        />
      </aside>

      {/* Mobile overlay */}
      {mobileOpen ? (
        <div className="md:hidden fixed inset-0 z-40 flex">
          <div className="fixed inset-0 bg-black/40" onClick={() => setMobileOpen(false)} />
          <aside className="relative w-72 bg-white shadow-xl flex flex-col">
            <button
              type="button"
              className="absolute top-3 right-3 p-2 rounded-md hover:bg-slate-100"
              onClick={() => setMobileOpen(false)}
              aria-label="Close menu"
            >
              <X className="h-5 w-5" />
            </button>
            <SidebarContent
              user={user}
              pathname={pathname}
              nav={visibleNav}
              onSignOut={signOut}
              onNavigate={() => setMobileOpen(false)}
              formNo={formNo}
            />
          </aside>
        </div>
      ) : null}

      <div className="flex-1 flex flex-col min-w-0">
        <header className="md:hidden sticky top-0 z-30 flex items-center justify-between bg-white border-b border-slate-200 px-4 py-3">
          <button
            type="button"
            className="p-2 -ml-2 rounded-md hover:bg-slate-100"
            onClick={() => setMobileOpen(true)}
            aria-label="Open menu"
          >
            <Menu className="h-5 w-5" />
          </button>
          <div className="font-semibold">Franklin ePermit</div>
          <div className="w-9" />
        </header>
        <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-x-hidden">{children}</main>
      </div>
    </div>
  );
}

function SidebarContent({
  user,
  pathname,
  nav,
  onSignOut,
  onNavigate,
  formNo = "FOI-SG-057",
}: {
  user: UserRow;
  pathname: string;
  nav: NavItem[];
  onSignOut: () => void;
  onNavigate?: () => void;
  formNo?: string;
}) {
  // Highlight only the most specific matching menu item, so "Permits" and
  // "New Hot Work Permit" are not lit up while on a deeper page such as
  // /permits/new/lifting.
  const activeHref = nav
    .filter(
      (item) => pathname === item.href || pathname.startsWith(item.href + "/"),
    )
    .sort((a, b) => b.href.length - a.href.length)[0]?.href;

  return (
    <>
      <div className="p-4 border-b border-slate-200">
        <div className="flex items-center gap-3">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src="/logo.png"
            alt="Franklin Offshore"
            className="h-9 w-9 object-contain"
          />
          <div>
            <div className="font-semibold text-sm leading-tight">Franklin ePermit</div>
            <div className="text-xs text-slate-500">{formNo}</div>
          </div>
        </div>
      </div>

      <nav className="flex-1 p-2 overflow-y-auto">
        {nav.map((item) => {
          const active = item.href === activeHref;
          const Icon = item.icon;
          return (
            <Link
              key={item.href}
              href={item.href}
              onClick={onNavigate}
              className={cn(
                "flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium",
                active
                  ? "bg-blue-50 text-blue-700"
                  : "text-slate-700 hover:bg-slate-100",
              )}
            >
              <Icon className="h-5 w-5" />
              {item.label}
            </Link>
          );
        })}
      </nav>

      <div className="p-3 border-t border-slate-200 space-y-2">
        <div className="px-2 py-1">
          <div className="text-sm font-medium truncate">{user.full_name}</div>
          <div className="text-xs text-slate-500 truncate">{user.email}</div>
          <div className="text-xs text-slate-400 mt-0.5 capitalize">{user.role}</div>
        </div>
        <button
          type="button"
          onClick={onSignOut}
          className="w-full flex items-center gap-2 px-3 py-2 rounded-md text-sm text-slate-700 hover:bg-slate-100"
        >
          <LogOut className="h-4 w-4" /> Sign out
        </button>
      </div>
    </>
  );
}
