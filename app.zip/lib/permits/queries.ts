import "server-only";
import { canSeePermitType } from "@/lib/permits/type-permissions";
import type { SupabaseClient } from "@supabase/supabase-js";
import { createServerSupabase } from "@/lib/supabase/server";
import type {
  PermitDocumentRow,
  PermitEndorsementRow,
  PermitPhotoRow,
  PermitRow,
  PermitStageRow,
  PermitWithJoins,
} from "@/lib/supabase/types";
import { createServiceRoleSupabase } from "@/lib/supabase/server";
import {
  effectivePermitState,
  groupEndorsedDays,
} from "@/lib/permits/effective-state";

const PERMIT_WITH_JOINS = `
  *,
  applicant:applicant_id (id, full_name, department, email),
  assessor:assessor_id (id, full_name, department, email),
  srm:srm_id (id, full_name, department, email),
  closer:closer_id (id, full_name, department, email),
  site:site_id (
    id,
    code,
    name,
    company:company_id (
      id,
      code,
      name
    )
  )
`;

export async function listPermits(opts?: {
  state?: PermitRow["state"][];
  applicantId?: string;
  companyId?: string;
  limit?: number;
}): Promise<PermitWithJoins[]> {
  const supabase = await createServerSupabase();

  const { data: session } = await supabase.auth.getUser();
  if (!session.user) return [];
  const { data: viewer } = await supabase.from("users").select("role,active,qualified_for").eq("id",session.user.id).maybeSingle();
  if (!viewer || !viewer.active) return [];
  let q = supabase
    .from("permits")
    .select(PERMIT_WITH_JOINS)
    .order("created_at", {
      ascending: false,
    });

  if (opts?.state?.length) {
    q = q.in("state", opts.state);
  }

  // companyId scopes to every permit raised for that company (e.g. all CFE
  // permits), regardless of who the applicant was. Takes priority over
  // applicantId, which scopes to a single user's own permits.
  if (opts?.companyId) {
  const { data: sites } = await supabase
    .from("sites")
    .select("id")
    .eq("company_id", opts.companyId);

  const siteIds = (sites ?? []).map((s) => s.id);

  q = q.in("site_id", siteIds);
  } else if (opts?.applicantId) {
    q = q.eq("applicant_id", opts.applicantId);
  }

  if (opts?.limit) {
    q = q.limit(opts.limit);
  }

  const { data, error } = await q;

  if (error) {
    throw error;
  }

  const permits = ((data ?? []) as unknown as PermitWithJoins[])
    .filter(p => canSeePermitType(viewer, p.permit_type) && !(p as PermitWithJoins & { deleted_at?: string | null }).deleted_at);

  if (!permits.length) return permits;

  // Show the real status: derive Approved/Active vs Pending Daily
  // Endorsement from the endorsement records instead of trusting the stored
  // state. Service role, because RLS can hide endorsement rows from some
  // roles (same reason the permit detail page reads them this way).
  const service = createServiceRoleSupabase();
  const { data: endorsementRows, error: endorsementError } = await service
    .from("permit_endorsements")
    .select("permit_id, day_number")
    .in(
      "permit_id",
      permits.map((p) => p.id),
    );

  if (endorsementError) {
    console.error("Failed to load endorsements for status", endorsementError);
    return permits;
  }

  const endorsedByPermit = groupEndorsedDays(endorsementRows);

  return permits.map((p) => ({
    ...p,
    state: effectivePermitState(p, endorsedByPermit.get(p.id) ?? []),
  }));
}

export async function getPermit(
  id: string,
  client?: SupabaseClient,
): Promise<PermitWithJoins | null> {
  const supabase = client ?? (await createServerSupabase());

  const { data, error } = await supabase
    .from("permits")
    .select(PERMIT_WITH_JOINS)
    .eq("id", id)
    .maybeSingle();

  if (error) {
  console.error("SUPABASE ERROR:", error);
  throw new Error(error.message);
}

  if (!data || (data as {deleted_at?: string | null}).deleted_at) return null;
  const { data: auth } = await supabase.auth.getUser();
  if (!auth.user) return null;
  const { data: viewer } = await supabase.from("users").select("role,active,qualified_for").eq("id",auth.user.id).maybeSingle();
  if (!viewer || !canSeePermitType(viewer, data.permit_type)) return null;
  return data as unknown as PermitWithJoins;
}

export async function getPermitStages(
  permitId: string,
  client?: SupabaseClient,
): Promise<PermitStageRow[]> {
  const supabase = client ?? (await createServerSupabase());

  const { data, error } = await supabase
    .from("permit_stages")
    .select("*")
    .eq("permit_id", permitId)
    .order("submitted_at", { ascending: true });

  if (error) {
    throw error;
  }

  return (data ?? []) as PermitStageRow[];
}

export async function getEndorsements(
  permitId: string,
  client?: SupabaseClient,
): Promise<PermitEndorsementRow[]> {
  const supabase = client ?? (await createServerSupabase());

  const { data, error } = await supabase
    .from("permit_endorsements")
    .select("*")
    .eq("permit_id", permitId)
    .order("day_number", { ascending: true });

  if (error) {
    throw error;
  }

  return (data ?? []) as PermitEndorsementRow[];
}

export async function getPhotos(
  permitId: string,
  client?: SupabaseClient,
): Promise<PermitPhotoRow[]> {
  const supabase = client ?? (await createServerSupabase());

  const { data, error } = await supabase
    .from("permit_photos")
    .select(
      "id, permit_id, storage_path, annotation_data, caption, uploaded_by, uploaded_at",
    )
    .eq("permit_id", permitId)
    .order("uploaded_at", { ascending: true });

  if (error) {
    throw error;
  }

  return (data ?? []) as PermitPhotoRow[];
}

export async function getPermitDocuments(
  permitId: string,
  client?: SupabaseClient,
): Promise<PermitDocumentRow[]> {
  const supabase = client ?? (await createServerSupabase());

  const { data, error } = await supabase
    .from("permit_documents")
    .select("*")
    .eq("permit_id", permitId)
    .order("created_at", { ascending: true });

  if (error) {
    throw error;
  }

  return (data ?? []) as PermitDocumentRow[];
}


export async function getCompaniesAndSites(userId: string, userRole?: string) {
  const supabase = createServiceRoleSupabase();

  // Admins may access both entities where necessary (per Alex's spec:
  // "Selected Admin and Assessor roles may access both entities where
  // necessary") — so admins always see every active company/site,
  // regardless of what's in their own user_site_roles rows.
  if (userRole === "admin") {
    const { data: allCompanies, error: companiesError } = await supabase
      .from("companies")
      .select("*")
      .eq("active", true);

    if (companiesError) throw companiesError;

    const { data: allSites, error: sitesError } = await supabase
      .from("sites")
      .select("*")
      .eq("active", true);

    if (sitesError) throw sitesError;

    return {
      companies: allCompanies ?? [],
      sites: allSites ?? [],
    };
  }

  const { data: roles, error } = await supabase
    .from("user_site_roles")
    .select("company_id, site_id")
    .eq("user_id", userId)
    .eq("active", true);

  if (error) throw error;

  const companyIds = [
    ...new Set((roles ?? []).map((r) => r.company_id).filter(Boolean)),
  ];
  const siteIds = [
    ...new Set((roles ?? []).map((r) => r.site_id).filter(Boolean)),
  ];

  // Backward compatibility: some existing SRM/applicant accounts have a
  // company assignment on users.company_id but were never migrated into
  // user_site_roles. Only use that company's sites, never all sites.
  if (companyIds.length === 0) {
    const { data: userProfile, error: profileError } = await supabase
      .from("users")
      .select("company_id, active")
      .eq("id", userId)
      .maybeSingle();

    if (profileError) throw profileError;
    if (!userProfile?.active || !userProfile.company_id) {
      return { companies: [], sites: [] };
    }

    const { data: fallbackCompany, error: fallbackCompanyError } = await supabase
      .from("companies")
      .select("*")
      .eq("id", userProfile.company_id)
      .eq("active", true)
      .maybeSingle();
    if (fallbackCompanyError) throw fallbackCompanyError;
    if (!fallbackCompany) return { companies: [], sites: [] };

    const { data: fallbackSites, error: fallbackSitesError } = await supabase
      .from("sites")
      .select("*")
      .eq("company_id", fallbackCompany.id)
      .eq("active", true);
    if (fallbackSitesError) throw fallbackSitesError;
    return { companies: [fallbackCompany], sites: fallbackSites ?? [] };
  }

  const { data: companies } = await supabase
    .from("companies")
    .select("*")
    .in("id", companyIds)
    .eq("active", true);

  let sitesData = [];

  if (siteIds.length > 0) {
    const { data } = await supabase
      .from("sites")
      .select("*")
      .in("id", siteIds)
      .eq("active", true);

    sitesData = data ?? [];
  } else {
    const { data } = await supabase
      .from("sites")
      .select("*")
      .in("company_id", companyIds)
      .eq("active", true);

    sitesData = data ?? [];
  }

  return {
    companies: companies ?? [],
    sites: sitesData,
  };
}